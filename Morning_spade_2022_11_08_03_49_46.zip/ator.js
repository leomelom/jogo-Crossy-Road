//variaveis do ator
let yPersonagem = 366;
let xPersonagem = 85;
let colisao = false;
let comprimentocarro =50;
let alturacarro = 40;
let meusPontos = 0;

function marcaPonto(){
  if (yPersonagem < 15){
    meusPontos += 1;
    somPonto.play();
    voltaInicial();
  }
}


function incluiPontos(){
  textAlign(CENTER); 
  textSize(23);
  fill (color (0,0,128))
  text(meusPontos, width /5, 25);
  
}

function voltaInicial(){
  yPersonagem = 366;
}

function mostraAtor(){
  image(imagemPersonagem,xPersonagem, yPersonagem,30,30);
  print(yPersonagem);
}
  
function movimentaPersonagem(){
  if(keyIsDown(UP_ARROW)){
    yPersonagem -= 3;
  }
  if(keyIsDown(DOWN_ARROW)){
    if (yAtor < 366){
      yPersonagem += 3;}
  }
}

function verificaColisao(){
  //collideRectCircle(x1, y1, width1, height1, cx, cy, diameter)
  for(let i =0;i < imagemCarros.length; i++ ){          
     colisao = collideRectCircle(xCarros[i], yCarros[i], comprimentocarro, alturacarro, xPersonagem, yPersonagem, 15);
    if(colisao){
      voltaInicial();
      somColisao.play();
      if (meusPontos > 0){
          meusPontos -= 1;
        
      }
    }
  }
}


