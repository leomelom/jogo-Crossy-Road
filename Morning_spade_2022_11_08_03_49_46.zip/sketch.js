function setup() {
  createCanvas(500, 400);
  somtrilha.loop();
}
function draw() {
  background(imagemEstrada);
  mostraAtor();  
  mostraCarro();
  movimentaCarro();
  movimentaPersonagem();
  VoltaDoCarro();
  verificaColisao();
  incluiPontos();
  marcaPonto();
}