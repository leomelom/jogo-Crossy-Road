//sons
let somTrilha, somColisao, somPonto;

//variaveis das imagens
let imagemEstrada;
let imagemPersonagem;
let imagemCarro1;
let imagemCarro2;
let imagemCarro3;

function preload(){
  imagemEstrada = loadImage("imagens/estrada.png");
  imagemPersonagem = loadImage("imagens/ator1.png");
  imagemCarro1 = loadImage("imagens/carro1.png");
  imagemCarro2 = loadImage("imagens/carro2.png");
  imagemCarro3 = loadImage("imagens/carro3.png");
  imagemCarros = [imagemCarro1, imagemCarro2, imagemCarro3, imagemCarro1, imagemCarro2, imagemCarro3];
  somTrilha = loadSound("sons/trilha.mp3");
  somColisao = loadSound("sons/colidiu.mp3");
  somPonto = loadSound("sons/pontos.mp3"); 
  
}